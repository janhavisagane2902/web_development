!C:\Users\janha\AppData\Local\Programs\Python\Python39\python.exe
import cgi
import mysql.connector as mycon

print("Content-type:text/html")
print()

con=mycon.connect(host='localhost',user='root',password='290200',database='automobilestore')
curs=con.cursor

form=cgi.FieldSttorage()
userid=form.getvalue("userid")
password=form.getvalue("password")

curs.execute("select * from users where userid='%s' and pswd='%s'"%(userid,password))
rec=curs.fetchone()

if rec:
    print("<html>")
    print("<head>")
    print("<meta http-equiv='refresh'content='0;url=login.html'/>")
    print("</head>")
    print("/html")
else:
    print("<h2>Sorry authentication failed</h2>")
    print("<a href='index.html'>Home</a>>")

con.close()