!C:\Users\janha\AppData\Local\Programs\Python\Python39\python.exe
import cgi
import mysql.connector

print("Content-type: text/html")
print()

con=mysql.connector.connect(host='localhost',user='root',password='290200',database='automobilestore')
curs=con.cursor()

form=cgi.FieldStorage()
userid=form.getvalue("userid")
name=form.getvalue("name")
emailid=form.getvalue("emailid")
address=form.getvalue("address")
mobileno=form.getvalue("mobileno")

curs.execute("insert into customers values('%s','%s','%s','%s','%s')" %(userid,name,emailid,address,mobileno))
con.commit()

print("<h3>User registration successful</h3>")
print("<a href='frontpage.html'>Home</a>")

con.close()