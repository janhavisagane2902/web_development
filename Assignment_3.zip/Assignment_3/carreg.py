!C:\Users\janha\AppData\Local\Programs\Python\Python39\python.exe
import cgi
import mysql.connector

print("Content-type: text/html")
print()

con=mysql.connector.connect(host='localhost',user='root',password='290200',database='automobilestore')
curs=con.cursor()

form=cgi.FieldStorage()
carName=form.getvalue("carName")
wheelsno=form.getvalue("wheelsno")
engineCapacity=form.getvalue("engineCapacity")
price=form.getvalue("price")

curs.execute("insert into customers values('%s','%d','%s','%d')" %(carName,wheelsno,engineCapacity,price))
con.commit()

print("<h3>Car registration successful</h3>")
print("<a href='index.html'>Home</a>")

con.close()